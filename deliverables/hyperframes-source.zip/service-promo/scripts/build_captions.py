from pathlib import Path
import json,html,re
root=Path(__file__).resolve().parents[1]
words=json.loads((root/'assets/transcript-edited.json').read_text())
# Group on phrase boundaries and safe mobile line widths, not fixed time slices.
pairs={'không cần chứng minh thu nhập','không thẩm định người thân','hỗ trợ','căn cước','công dân','thu nhập','người thân','Đà Nẵng','Quy Nhơn','18 tuổi','15 triệu','50 triệu','thẩm định','thành phố','nhu cầu','tư vấn','liên hệ'}
units=[];i=0
while i<len(words):
 matched=0
 for count in range(min(6,len(words)-i),1,-1):
  phrase=' '.join(re.sub(r'[,.?!]','',x['text']).casefold() for x in words[i:i+count])
  if phrase in {p.casefold() for p in pairs}:
   matched=count;break
 if matched:units.append(words[i:i+matched]);i+=matched
 else:units.append(words[i:i+1]);i+=1
groups=[];cur=[]
for unit in units:
 text=' '.join(w['text'] for w in cur+unit)
 pause=cur and unit[0]['start']-cur[-1]['end']>.25
 sentence=cur and unit[0]['text'] in {'Nhưng','Thì','Không','Hạn','Đó','Hiện','Nên','Mà','Và'}
 conjunction=cur and len(cur)>=3 and unit[0]['text'].lower() in {'nhưng','mà','thì','nên'}
 if cur and (len(text)>27 or len(cur+unit)>6 or pause or conjunction or sentence):groups.append(cur);cur=[]
 cur+=unit
 if re.search('[,.?!]$',cur[-1]['text']):groups.append(cur);cur=[]
if cur:groups.append(cur)
css=(root/'compositions/titles.html').read_text();fontcss=css[css.index('@font-face'):css.index('#root{')]
parts=['<template id="captions-template"><div id="root" data-composition-id="captions" data-width="1080" data-height="1920"><style>'+fontcss+'''
#root{width:100%;height:100%;position:relative;background:transparent;font-family:'Be Vietnam Pro';font-weight:800;color:#FFFDF5}
.caption{position:absolute;inset:0;overflow:visible}
.caption-text{position:absolute;left:105px;right:145px;top:1210px;text-align:center;font-size:59px;line-height:1.3;letter-spacing:-1.4px;white-space:nowrap;max-width:830px;paint-order:stroke fill;-webkit-text-stroke:6px #171711;text-shadow:0 5px 1px #171711}
.word{display:inline-block}
</style>''']
tweens=[];cues=[]
for gi,g in enumerate(groups):
 a=max(.04,g[0]['start']);b=min(45.6,max(a+.22,g[-1]['end']+.05))
 if gi+1<len(groups):b=min(b,max(a+.1,groups[gi+1][0]['start']))
 spans=[]
 for wi,w in enumerate(g):
  wid=f'w-{gi}-{wi}';txt=w['text'];display=re.sub(r'\bvay\b','v*y',txt,flags=re.I)
  spans.append(f'<span class="word" id="{wid}">{html.escape(display)}</span>')
  if w['end']-w['start']>=0.065:
   tweens.append(f"tl.to('#{wid}',{{color:'#FFD34D',duration:0.06,ease:'none'}},{max(a,w['start']):.3f});")
   tweens.append(f"tl.to('#{wid}',{{color:'#FFFDF5',duration:0.06,ease:'none'}},{min(b,w['end']):.3f});")
 parts.append(f'<div class="clip caption" id="cg-{gi}" data-start="{a:.3f}" data-duration="{b-a:.3f}" data-track-index="0"><div class="caption-text" id="ct-{gi}">'+ ' '.join(spans)+'</div></div>')
 tweens.append(f"tl.from('#ct-{gi}',{{y:12,opacity:0,duration:0.13,ease:'power3.out'}},{a:.3f});")
 tweens.append(f"tl.set('#ct-{gi}',{{opacity:0}},{b:.3f});")
 cues.append({'start':a,'end':b,'text':' '.join(w['text'] for w in g)})
parts.append('<script>const tl=gsap.timeline({paused:true});'+''.join(tweens)+"window.__timelines=window.__timelines||{};window.__timelines.captions=tl;</script></div></template>")
(root/'compositions/captions.html').write_text('\n'.join(parts))
(root/'caption-cues.json').write_text(json.dumps(cues,ensure_ascii=False,indent=2))
def stamp(t):
 ms=round(t*1000);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
(root/'captions.srt').write_text('\n\n'.join(f"{i+1}\n{stamp(c['start'])} --> {stamp(c['end'])}\n{c['text']}" for i,c in enumerate(cues)))
print('Caption groups:',len(cues))
