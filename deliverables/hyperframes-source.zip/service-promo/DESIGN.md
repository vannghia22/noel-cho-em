# Visual identity
## Style Prompt
Vietnamese presenter advertisement: direct, warm and credible. Preserve the real presenter and real source claims. Ivory typography with strong charcoal outlines and marigold emphasis; no boxes over the speaker. No unrelated stock footage. Restrained camera reframing; preserve the face and natural skin.
## Colors
- #FFFDF5 — main typography
- #FFD34D — important words and numbers
- #171711 — outline and contrast
## Typography
Be Vietnam Pro 800, bundled locally, Vietnamese and Latin subsets.
## What NOT to Do
- No invented prices, age eligibility, rates, guarantees or testimonials.
- No unrelated stock footage or flashing transitions.
- No captions across the face or platform action rail.
- No fake brand identity.
- No unverified bleep timestamps.
