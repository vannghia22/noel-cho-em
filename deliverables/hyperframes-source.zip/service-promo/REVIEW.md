# Kiểm tra bản dựng

## Quyết định sáng tạo
Giữ người thật và nội dung thật làm trung tâm. Dùng hook về tuổi, các con số và giới hạn địa bàn. Chữ viền trắng/vàng, không khung; zoom nhẹ tối đa4% theo nội dung. Không chèn b-roll không liên quan, không bịa thương hiệu hoặc ưu đãi.

## Kiểm tra đã thực hiện
- Nhận dạng3lượt: small, small có ngữ cảnh và large-v3-turbo đa ngôn ngữ. Đọc/đối chiếu transcript; dùng bản turbo cho timing. Chỉnh lỗi chính tả/nghe nhầm căn cước, trở lên, hạn mức và lời OK. Phần cuối được làm rõ thành “lên hồ sơ trực tiếp”.
- Giữ số18,15,50 và địa danh nhất quán giữa các lượt nhận dạng.
- Sửa lỗi phân nhóm khiến “Không” rơi vào câu trước; chụp lại12,6/14,2/15,8s để xác minh đầy đủ câu phủ định.
- HyperFrames lint/runtime/layout/contrast/craft: pass, không findings trong lượt delivery-check.
- Xem khung hình thật tại1,1/5,5/12,6/14,2/15,8/19,8/31,8/41,8/44,6s. Chữ không che mặt và không tràn khung.
- Hai từ mẫu “vay”, “nợ xấu” không có trong transcript; không tạo bíp giả hoặc che nhầm lời thoại. sensitive-word-audit.json ghi rõ.

## Giới hạn
Âm thanh được xử lý/đo, không được agent nghe trực tiếp. Phụ đề dựa trên ASR đã đối chiếu, không có bản transcript do người nói xác nhận. Thông tin dịch vụ lấy từ footage, chưa kiểm chứng độc lập. Xuất1080p từ nguồn720p; không tạo thêm chi tiết thật. Không cam kết duyệt quảng cáo nền tảng.

## Kiểm tra file xuất
Xem deliverables/QC.json và QC.md được tạo sau khi render.
