# Quảng cáo dịch vụ — HyperFrames

Video dọc từ footage do người dùng cung cấp. Project giữ video gốc, giọng nói thật, phụ đề có thời gian từng từ, chữ nhấn nội dung và audio tách riêng.

## Chỉnh sửa và render
Cần Node.js >=22, FFmpeg/FFprobe và Chromium. Chạy trong thư mục project, dùng checkout hiện có; không tạo Git worktree.

```sh
npm run check
npm run dev
HYPERFRAMES_BROWSER_PATH=/usr/bin/chromium npm run render -- --output renders/service-promo-final.mp4 --fps 30 --quality high --workers 2
```

Trong môi trường cloud này, thêm `npm_config_cache=/workspace/.npm-cache` trước lệnh npm. Preview nền dùng `XDG_STATE_HOME=/workspace/.state npm_config_cache=/workspace/.npm-cache npx --yes hyperframes@0.8.185 preview --background`.

## Nội dung project
- index.html: footage, camera, audio và các lớp đồ họa.
- compositions/titles.html: hook, điều kiện, hạn mức, khu vực, CTA.
- compositions/captions.html: 38 cụm phụ đề, highlight từng từ.
- assets/transcript-edited.json: từ và timestamp có thể chỉnh sửa. Sau khi sửa, chạy `python3 scripts/build_captions.py`, rồi check và snapshot lại.
- captions.srt: phụ đề tách rời.
- assets/source.mp4: bản sao nguyên vẹn của file gốc.
- assets/presenter-edit.mp4: proxy dựng với keyframe mỗi giây.
- assets/dialogue.wav: thoại đã cân âm lượng.
- assets/music-final.wav: nhạc nền đã duck theo giọng nói và fade cuối.
- assets/sfx: hiệu ứng nhấn số và chuyển vùng nội dung.
- ASSETS.md, REVIEW.md, SPEC.md: nguồn tài nguyên, kiểm tra và quyết định dựng.

Không cần tải mô hình ASR để mở hoặc render lại project: transcript đã được lưu. Nếu nhận dạng lại, dùng mô hình đa ngôn ngữ và `vi`, không dùng model `.en`.
