# Đặc tả bản dựng cuối

Nguồn: footage người dùng 46,8 giây, 720×1280, 30fps, H.264/AAC, SDR BT.709.
Timeline cuối: 45,6 giây; cắt phần dư cuối, giữ trọn lời nói.
Xuất: 1080×1920, 30fps, MP4 H.264/AAC. Nguồn được upscale; không khẳng định chi tiết quay native 1080p.

Hook: câu hỏi 18 tuổi có được hỗ trợ. Điều kiện, hạn mức và khu vực lấy từ lời thoại: căn cước công dân, từ 18 tuổi, 15–50 triệu, Đà Nẵng và Quy Nhơn. Các thông tin dịch vụ là phát biểu trong footage, chưa được kiểm chứng độc lập.
Chữ: Be Vietnam Pro 800, trắng ngà #FFFDF5, vàng #FFD34D, viền #171711. Không khung chữ. Caption x=105..935, y=1210; key text vùng trên mặt, y=235. Face không bị chữ che.
Camera: zoom 1.00–1.04, các điểm theo câu thoại; không speed ramp lời nói. Giữ màu nguồn.
Audio: thoại thật, high-pass 70Hz, loudness normalization; nhạc gốc thủ tục ở mức thấp, duck theo thoại; hai pop nhẹ và một whoosh.
Không tự thêm lãi suất, phí, cam kết duyệt hay thông tin liên hệ chưa có.
Không phát hiện hai cụm từ mẫu cần che trong các lượt ASR; không bíp tùy tiện. Không khẳng định được nền tảng duyệt quảng cáo.
