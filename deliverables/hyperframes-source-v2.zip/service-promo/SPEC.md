# V2 spec
44,1666667s;1325frame;1080×1920;30fps;MP4H.264/AAC.
Chữ BeVietnamPro900;white#FFFFFF,lime#DFFF3F,cyan#52E1F0,outline#11120F. Caption y1132, width828, một hoặc hai dòng; glyph-fit tối đa790px. Text không có khung. Camera scale1.05–1.22, điểm nhấn theo lời thoại, ease0.16–0.24s rồi giữ crop. SVG xuất hiện theo chủ đề, không có dữ liệu định danh thật. Thoại và video được trim đồng thời; music duck theo thoại V2.
