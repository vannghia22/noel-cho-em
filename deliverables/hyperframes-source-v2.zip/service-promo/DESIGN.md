# Visual identity — TikTok V2
## Style Prompt
Bold creator-led TikTok advertisement. Big uppercase Vietnamese captions with disciplined line breaks. Lime punctuation on the spoken numbers, cyan document/location illustrations. Clear punch-ins and rhythmic resets; preserve the original speaker and claims. Text is outlined, never put into caption boxes. The only rectangles are symbolic document illustrations.
## Colors
- #FFFFFF — captions
- #DFFF3F — numbers and important words
- #52E1F0 — illustrative documents and pins
- #11120F — outlines
## Typography
Be Vietnam Pro 900, locally bundled Vietnamese/Latin.
## What NOT to Do
- No tiny karaoke words or 0.12-second filler captions.
- No 7-second unchanged floating headlines.
- No invented rates, approvals, contacts, eligibility or testimonial claims.
- No real-looking personal ID data or fake map geography.
- No irrelevant b-roll or face-covering graphics.
