from pathlib import Path
import json,tarfile,html,re,sys
sys.path.insert(0,"/workspace/tools/font-metrics")
from fontTools.ttLib import TTFont
p=Path(__file__).resolve().parents[1]
D=1325/30
segs=[(0,235/30),(256/30,817/30),(827/30,1356/30)]
def clock(t):
 shift=0
 for a,b in segs:
  if a<=t<=b:return t-a+shift
  shift+=b-a
 raise ValueError(t)
(p/'DESIGN.md').write_text('''# Visual identity — TikTok V2
## Style Prompt
Bold creator-led TikTok advertisement. Big uppercase Vietnamese captions with disciplined line breaks. Lime punctuation on the spoken numbers, cyan document/location illustrations. Clear punch-ins and rhythmic resets; preserve the original speaker and claims. Text is outlined, never put into caption boxes. The only rectangles are symbolic document illustrations.
## Colors
- #FFFFFF — captions
- #DFFF3F — numbers and important words
- #52E1F0 — illustrative documents and pins
- #11120F — outlines
## Typography
Be Vietnam Pro 900, locally bundled Vietnamese/Latin.
## What NOT to Do
- No tiny karaoke words or 0.12-second filler captions.
- No 7-second unchanged floating headlines.
- No invented rates, approvals, contacts, eligibility or testimonial claims.
- No real-looking personal ID data or fake map geography.
- No irrelevant b-roll or face-covering graphics.
''')
font="""@font-face{font-family:BVP;font-weight:900;src:url('assets/fonts/be-vietnam-pro-vietnamese-900-normal.woff2') format('woff2');unicode-range:U+0102-0103,U+0110-0111,U+0128-0129,U+0168-0169,U+01A0-01A1,U+01AF-01B0,U+0300-0301,U+0303-0304,U+0308-0309,U+0323,U+0329,U+1EA0-1EF9,U+20AB}@font-face{font-family:BVP;font-weight:900;src:url('assets/fonts/be-vietnam-pro-latin-900-normal.woff2') format('woff2')}"""
fonts=[TTFont(p/f'assets/fonts/be-vietnam-pro-{sub}-900-normal.woff2') for sub in ['vietnamese','latin']]
def fit(text,base,tracking=-2.5):
 width=0
 for c in text:
  for f in fonts:
   cmap=f.getBestCmap()
   if ord(c) in cmap:
    width+=f['hmtx'].metrics[cmap[ord(c)]][0]/f['head'].unitsPerEm;break
  else:width+=.65
 return min(base,(790-tracking*max(0,len(text)-1))/max(width,.01))
# Deliberate semantic subtitle cues. No isolated function words or broken negations.
cues=[(0,1.88,'EM MUỐN GÓP','15 TRIỆU'),(1.88,3.48,'MÀ KHÔNG THẨM ĐỊNH','NGƯỜI THÂN'),(3.48,5.05,'NHƯNG NĂM NAY','EM CHỈ MỚI'),(5.05,5.92,'18 TUỔI',''),(5.92,7.70,'THÌ BÊN EM','CÓ HỖ TRỢ ĐƯỢC KHÔNG?'),(8.82,10.83,'OK EM! HIỆN TẠI','BÊN EM CHỈ CẦN'),(10.83,12.1,'CÓ CĂN CƯỚC','CÔNG DÂN'),(12.1,13.2,'ĐỦ TỪ 18 TUỔI','TRỞ LÊN'),(13.2,15.13,'KHÔNG CẦN','CHỨNG MINH THU NHẬP'),(15.14,16.26,'KHÔNG THẨM ĐỊNH','NGƯỜI THÂN'),(16.26,18.2,'HẠN MỨC BÊN EM','HỖ TRỢ LÊN ĐẾN TỪ'),(18.2,20.8,'15 CHO ĐẾN','50 TRIỆU ĐỒNG EM Ạ'),(20.8,22.68,'ĐÓ LÀ CON SỐ','KHÁ LÀ LỚN'),(22.68,24.44,'ĐỐI VỚI NHỮNG BẠN','Ở TẦM TUỔI NÀY'),(24.5,27.13,'NHƯNG HIỆN TẠI','BÊN EM CÓ THỂ HỖ TRỢ'),(27.76,29.66,'HIỆN TẠI EM CHỈ','CÓ THỂ HỖ TRỢ TẠI'),(29.66,31.32,'THÀNH PHỐ','ĐÀ NẴNG'),(31.32,32.66,'VÀ THÀNH PHỐ','QUY NHƠN MÀ THÔI'),(32.68,34.54,'NÊN BẠN NÀO','ĐANG Ở TRONG'),(34.54,36.51,'2 THÀNH PHỐ NÀY',''),(36.58,38.34,'MÀ CÓ NHU CẦU','THÌ CỨ LIÊN HỆ'),(38.34,40.49,'CHO BÊN EM','ĐỂ ĐƯỢC HỖ TRỢ TƯ VẤN'),(40.5,42.40,'VÀ HỖ TRỢ LÊN HỒ SƠ','TRỰC TIẾP TẠI'),(42.47,44.72,'THÀNH PHỐ MÌNH','ĐANG Ở LUÔN EM NHÉ')]
css=font+'''#root{width:100%;height:100%;position:relative;background:transparent;font-family:BVP;font-weight:900;color:#FFF}.clip{position:absolute;inset:0}.copy{position:absolute;left:96px;right:156px;top:1132px;text-align:center;max-width:828px;paint-order:stroke fill;-webkit-text-stroke:8px #11120F;text-shadow:0 7px 0 #11120F}.line{font-size:78px;line-height:1.11;letter-spacing:-2.5px;white-space:nowrap}.accent{color:#DFFF3F}.small{font-size:62px;letter-spacing:-1.7px}.one{font-size:110px}.word{display:inline-block}'''
parts=['<template id="captions-template"><div id="root" data-composition-id="captions" data-width="1080" data-height="1920"><style>'+css+'</style>'];tw=[];out=[]
for i,(a,b,l1,l2) in enumerate(cues):
 a=max(.03,clock(a));b=clock(b)+.04
 if i+1<len(cues):b=min(b,clock(cues[i+1][0]))
 def markup(t):
  return re.sub(r'(18|15|50|2)(?=\s|$)',r'<span class="accent">\1</span>',html.escape(t))
 lines=''
 for li,txt in enumerate([l1,l2]):
  if not txt:continue
  sz=' small' if len(txt)>21 else ''
  if not l2:sz=' one accent'
  lines+=f'<div class="line{sz}" id="c{i}-l{li}" style="font-size:{fit(txt,110 if not l2 else 78):.1f}px">{markup(txt)}</div>'
 parts.append(f'<div id="c{i}" class="clip" data-start="{a:.4f}" data-duration="{b-a:.4f}" data-track-index="{i//3}"><div id="copy{i}" class="copy">{lines}</div></div>')
 tw.append(f"tl.from('#copy{i}',{{scale:0.94,y:18,opacity:0,duration:0.18,ease:'back.out(1.3)'}},{a:.4f});tl.set('#copy{i}',{{opacity:0}},{b:.4f});")
 out.append({'start':a,'end':b,'text':l1+'\n'+l2})
parts.append('<script>const tl=gsap.timeline({paused:true});'+''.join(tw)+"window.__timelines=window.__timelines||{};window.__timelines.captions=tl;</script></div></template>")
(p/'compositions/captions.html').write_text('\n'.join(parts));(p/'caption-cues.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
def stamp(t):
 ms=round(t*1000);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
(p/'captions.srt').write_text('\n\n'.join(f'{i+1}\n{stamp(c["start"])} --> {stamp(c["end"])}\n{c["text"].strip()}' for i,c in enumerate(out)))
# Stylized contextual illustrations, no personal data and no fictitious geography.
svg={
'id':'''<svg viewBox="0 0 260 180"><rect x="12" y="18" width="230" height="144" rx="17" fill="#52E1F0" stroke="#11120F" stroke-width="9"/><path d="M23 60h207" stroke="#11120F" stroke-width="8"/><circle cx="69" cy="96" r="17" fill="#FFF" stroke="#11120F" stroke-width="6"/><path d="M40 139q2-34 29-34t29 34" fill="#FFF" stroke="#11120F" stroke-width="6"/><path d="M124 91h85m-85 22h67m-67 22h79" stroke="#11120F" stroke-width="8" stroke-linecap="round"/></svg>''',
'money':'''<svg viewBox="0 0 260 200"><g stroke="#11120F" stroke-width="7"><rect x="25" y="25" width="207" height="116" rx="10" fill="#52E1F0" transform="rotate(-15 128 83)"/><rect x="19" y="48" width="216" height="120" rx="10" fill="#DFFF3F" transform="rotate(7 128 108)"/><rect x="21" y="67" width="220" height="120" rx="10" fill="#FFF"/><circle cx="131" cy="127" r="34" fill="#DFFF3F"/><path d="M43 91h30m116 72h28"/></g><text x="131" y="143" text-anchor="middle" font-family="sans-serif" font-size="53" font-weight="bold" fill="#11120F">₫</text></svg>''',
'pin':'''<svg viewBox="0 0 150 180"><path d="M75 166S15 100 15 65a60 60 0 1 1 120 0c0 35-60 101-60 101" fill="#52E1F0" stroke="#11120F" stroke-width="9"/><circle cx="75" cy="65" r="22" fill="#FFF" stroke="#11120F" stroke-width="8"/></svg>''',
'folder':'''<svg viewBox="0 0 260 190"><path d="M15 158V30q0-10 12-10h76l23 25h109q10 0 10 12v101z" fill="#52E1F0" stroke="#11120F" stroke-width="9"/><path d="M15 158 37 69h215l-23 89z" fill="#DFFF3F" stroke="#11120F" stroke-width="9"/><path d="m97 110 23 22 45-50" fill="none" stroke="#11120F" stroke-width="11" stroke-linecap="round" stroke-linejoin="round"/></svg>'''}
for k,v in svg.items():(p/f'assets/{k}-v2.svg').write_text(v.replace('<svg ','<svg xmlns="http://www.w3.org/2000/svg" ',1))
# Upper callouts alternate with illustrations; timings follow source clock.
beats=[(.1,1.9,'15 TRIỆU?','', 'money'),(3.5,5.92,'MỚI 18 TUỔI?','',''),(8.82,10.5,'ĐƯỢC HỖ TRỢ','', ''),(10.83,13.2,'CĂN CƯỚC','CÔNG DÂN','id'),(13.2,15.14,'KHÔNG CẦN','CHỨNG MINH THU NHẬP',''),(15.14,16.9,'KHÔNG THẨM ĐỊNH','NGƯỜI THÂN',''),(18.2,20.8,'15 → 50','TRIỆU ĐỒNG','money'),(29.66,32.68,'ĐÀ NẴNG','QUY NHƠN','pin'),(37.84,40.5,'LIÊN HỆ','ĐỂ ĐƯỢC TƯ VẤN',''),(40.5,44.72,'LÊN HỒ SƠ','HỖ TRỢ TRỰC TIẾP','folder')]
css=font+'''#root{width:100%;height:100%;position:relative;background:transparent;font-family:BVP;font-weight:900;color:#FFF}.clip{position:absolute;inset:0}.content{width:100%;height:100%;padding:205px 145px 0 95px;display:flex;flex-direction:column;align-items:center;gap:6px}.headline{font-size:91px;line-height:1.14;letter-spacing:-3.2px;text-align:center;color:#DFFF3F;paint-order:stroke fill;-webkit-text-stroke:8px #11120F;text-shadow:0 8px 0 #11120F;white-space:nowrap}.sub{font-size:52px;color:#FFF;letter-spacing:-1.8px}.long{font-size:67px}.art{position:absolute;right:113px;top:405px;width:240px;height:185px;filter:drop-shadow(0 8px 0 rgba(17,18,15,.6))}.art svg{width:100%;height:100%}.pin{width:100px;height:125px;right:120px;top:370px}'''
parts=['<template id="titles-template"><div id="root" data-composition-id="titles" data-width="1080" data-height="1920"><style>'+css+'</style>'];tw=[]
for i,(a,b,big,sub,art) in enumerate(beats):
 a=clock(a);b=clock(b)
 parts.append(f'<div class="clip" id="beat{i}" data-start="{a:.4f}" data-duration="{b-a:.4f}" data-track-index="{i}" data-beat="beat{i}"><div class="content"><div id="h{i}" class="headline {"long" if len(big)>16 else ""}" style="font-size:{fit(big,145 if i==6 else 118,-3.2):.1f}px">{big}</div>'+ (f'<div id="s{i}" class="headline sub">{sub}</div>' if sub else '')+'</div>'+(f'<div id="a{i}" class="art {"pin" if art=="pin" else ""}">{svg[art]}</div>' if art else '')+'</div>')
 tw.append(f"tl.from('#h{i}',{{scale:1.18,rotation:-2,opacity:0,duration:0.28,ease:'back.out(1.15)'}},{a+.03:.4f});")
 if sub:tw.append(f"tl.from('#s{i}',{{x:-28,opacity:0,duration:0.26,ease:'expo.out'}},{a+.12:.4f});")
 if art:tw.append(f"tl.from('#a{i}',{{x:90,rotation:14,scale:0.7,opacity:0,duration:0.36,ease:'power4.out'}},{a+.15:.4f});")
parts.append('<script>const tl=gsap.timeline({paused:true});'+''.join(tw)+"window.__timelines=window.__timelines||{};window.__timelines.titles=tl;</script></div></template>")
(p/'compositions/titles.html').write_text('\n'.join(parts))
# Camera actions: decisive punch, held crop, controlled release. One property owner.
cam=[(0,1.06,.0),(clock(.64),1.16,.16),(clock(2),1.07,.22),(clock(5.05),1.22,.18),(clock(8.82),1.06,.16),(clock(11.23),1.15,.23),(clock(13.2),1.08,.20),(clock(15.14),1.16,.18),(clock(16.9),1.07,.22),(clock(18.2),1.20,.16),(clock(20.8),1.09,.2),(clock(24.5),1.15,.18),(clock(27.76),1.05,.18),(clock(30.55),1.14,.20),(clock(32.68),1.07,.24),(clock(36.58),1.16,.2),(clock(40.5),1.07,.2)]
style='''*{box-sizing:border-box;margin:0}html,body{width:1080px;height:1920px;overflow:hidden;background:#11120F}#root{position:relative;width:1080px;height:1920px;overflow:hidden}#camera{width:100%;height:100%;transform-origin:50% 78%;}#presenter{width:100%;height:100%;object-fit:cover}#titles{position:absolute;inset:0;z-index:2}#captions{position:absolute;inset:0;z-index:3}'''
body=f'<div id="root" data-composition-id="main" data-start="0" data-duration="{D}" data-width="1080" data-height="1920"><div id="camera"><video id="presenter" class="clip" src="assets/presenter-v2.mp4" data-start="0" data-duration="{D}" data-track-index="0" muted playsinline></video></div><audio id="dialogue" src="assets/dialogue-v2.wav" data-start="0" data-duration="{D}" data-track-index="1"></audio><audio id="music" src="assets/music-v2.wav" data-start="0" data-duration="{D}" data-track-index="4" data-volume="1"></audio>'
for name,start,asset,vol,du in [('age',5.05,'pop.mp3',.18,.57),('id',10.83,'whoosh-short.mp3',.12,.57),('amount',18.2,'impact-bass-1.mp3',.18,.8),('location',30.55,'pop.mp3',.15,.57),('cta',37.84,'whoosh-short.mp3',.12,.57)]:
 body+=f'<audio id="sfx-{name}" src="assets/sfx/{asset}" data-start="{clock(start):.4f}" data-duration="{du}" data-track-index="5" data-volume="{vol}"></audio>'
for id,kind,track in [('titles','graphics',2),('captions','captions',3)]:body+=f'<div id="{id}" class="clip" data-composition-id="{id}" data-composition-src="compositions/{id}.html" data-start="0" data-duration="{D}" data-track-index="{track}" data-track-kind="{kind}"></div>'
body+='</div>'
tw="const tl=gsap.timeline({paused:true});tl.set('#camera',{scale:1.06},0);"
for t,s,d in cam[1:]:tw+=f"tl.to('#camera',{{scale:{s},duration:{d},ease:'power3.out'}},{t:.4f});"
(p/'index.html').write_text(f'<!doctype html><html lang="vi"><head><meta charset="utf-8"><meta name="viewport" content="width=1080,height=1920"><script src="assets/gsap.min.js"></script><style>{style}</style></head><body>{body}<script>window.__timelines=window.__timelines||{{}};{tw}window.__timelines.main=tl;</script></body></html>')
(p/'EDIT_V2.md').write_text('TikTok V2: 24 semantic caption cues, 900 weight, lime/cyan graphics; explicit camera punches 6–22%; two pauses cut, final timeline 1325 frames at 30fps. All service numbers and regions remain from the original source. Illustrations are generic symbols, not real IDs or geographic maps.\n')
print('V2 composition written; duration',D)
