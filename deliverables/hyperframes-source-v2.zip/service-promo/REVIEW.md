# Review — TikTok V2

## Phản hồi đã xử lý
Người dùng chê V1 và chọn hướng TikTok mạnh. V2 đổi font sang900, chữ lớn viết hoa, lime/cyan, 24 cụm có chia dòng, punch-in6–22%, minh họa tài chính/căn cước/địa điểm/hồ sơ. Cắt hai khoảng nghỉ; giữ nguyên tốc độ và thông tin chính trong lời nói.

## Lỗi đã sửa trong quá trình dựng
- V1 có cue “mà” chỉ0,12s và nhiều cue chức năng ngắn. V2 chia cue có chủ đích theo ý nói.
- Phụ đề câu hỏi từng tràn phải: đo advance của glyph BeVietnamPro, fit tĩnh trước khi sinh HTML, chụp lại.
- SVG ngoài từng không hiện: chuyển sang SVG inline, xác minh ảnh thật; file tài nguyên cũng có namespace chuẩn.
- Giữ “không” cùng điều kiện tương ứng, không tách thành caption đảo nghĩa.

## Kiểm tra hình
Đã xem snapshots thật ở1,1/5,4/6,7/10,8/13,4/17,8/19/29,8/37/41,2s, và kiểm tra lại các hero sau khi tăng chữ và minh họa. Chủ thể được giữ trong khung; hình minh họa nằm ngoài mắt/miệng. Camera giữ crop sau mỗi punch, không rung hoặc thở liên tục.
HyperFrames delivery-check: pass, không findings. Chạy lại sau sửa cuối trước render.

## Giới hạn
Âm thanh đo kỹ thuật, chưa được agent nghe. Caption dùng ASR đã đối chiếu và biên tập câu chữ/linebreak; chưa có xác nhận từng chữ từ người nói. Một số từ đệm lặp được rút gọn, thông tin cốt lõi giữ nguyên. Nguồn720p được upscale. Không kiểm chứng độc lập điều kiện dịch vụ hoặc cam kết nền tảng duyệt.

Xem QC-V2.json trong gói nguồn để biết kết quả file xuất.
