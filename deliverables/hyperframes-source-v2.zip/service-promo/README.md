# TikTok V2 — HyperFrames

Bản dựng lại theo phản hồi: TikTok mạnh, chữ lớn, nhịp nhanh, punch-in và minh họa đúng lời nói. V1 được giữ riêng trên GitHub.

## Chạy và chỉnh sửa
Yêu cầu Node.js>=22, FFmpeg/FFprobe và Chromium. Trong thư mục project:

```sh
npm run check
npm run dev
HYPERFRAMES_BROWSER_PATH=/usr/bin/chromium npm run render -- --output renders/tiktok-v2.mp4 --fps 30 --quality high --workers 2
```

Cloud hiện tại thêm `npm_config_cache=/workspace/.npm-cache` trước lệnh npm. Preview nền dùng `XDG_STATE_HOME=/workspace/.state npm_config_cache=/workspace/.npm-cache npx --yes hyperframes@0.8.185 preview --background`.

- index.html: footage, audio, các punch-in và lớp đồ họa.
- compositions/captions.html: 24 cụm phụ đề viết hoa, chia dòng có chủ đích.
- compositions/titles.html: chữ nhấn và minh họa SVG trực tiếp.
- scripts/build_v2.py: khai báo các cue, timeline và chuyển đổi thời gian. Chỉ cần khi muốn sinh lại HTML; yêu cầu fonttools và brotli. Có thể sửa trực tiếp HTML mà không cần Python.
- assets/presenter-v2.mp4, dialogue-v2.wav, music-v2.wav: media đã căn theo timeline V2. Không cần chạy ASR để render lại.
- assets/source.mp4: bản sao nguyên vẹn footage gốc, không bị ghi đè.
- assets/*-v2.svg: minh họa biểu tượng căn cước, tiền, địa điểm, hồ sơ; không phải giấy tờ thật.
- captions.srt, caption-cues.json: phụ đề có thể chỉnh sửa.
- REVIEW.md và ASSETS.md: phạm vi kiểm tra và nguồn tài nguyên.

Dùng checkout hiện có, không tạo Git worktree khi không có yêu cầu. Không chạy script chia caption V1 lên V2. Các số/điều kiện/khu vực đều lấy từ footage; không thêm cam kết duyệt, lãi suất hoặc phí.
